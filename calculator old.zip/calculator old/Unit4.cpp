// ---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include <string>
#include "Unit4.h"
// ---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm4 *Form4;
float x, y = 0;
String operation;
int c = 0;
// ---------------------------------------------------------------------------
__fastcall TForm4::TForm4(TComponent* Owner) : TForm(Owner) {
}

// ---------------------------------------------------------------------------
void __fastcall TForm4::Button1Click(TObject *Sender) {
	if (c == 0) {
		Edit1->Text = ((TButton*)Sender)->Caption;
		c = 1;
	}
	else
		Edit1->Text += ((TButton*)Sender)->Caption;
	y = StrToFloat(Edit1->Text);
}

// ---------------------------------------------------------------------------
void __fastcall TForm4::Button12Click(TObject *Sender) {
	Edit1->Text = "";
	operation = "";
	c = 0;
	x = 0;
	y = 0;
}

// ---------------------------------------------------------------------------
void __fastcall TForm4::Button14Click(TObject *Sender) {

	if (c) {
		x = StrToFloat(Edit1->Text);
		operation = ((TButton*)Sender)->Caption;
		Edit1->Text+=(((TButton*)Sender)->Caption);
		c = 0;
	}
}

// ---------------------------------------------------------------------------
void __fastcall TForm4::Button11Click(TObject *Sender) {
int EditLen = Edit1->Text.Length();
	if (EditLen == 0){
		ShowMessage("Edit is empty.");
	}
	else{
		Edit1->Text="Result = " + (FloatToStrF(x, ffGeneral, 5,2));
	}
	if (operation == ""){
		 ShowMessage("Choose the operation.");
	}
	else if (operation == '+') {
		x = x + y;
		c = 0;
		Edit1->Text="Result = " + (FloatToStrF(x, ffGeneral, 5,2));
	}
	else if (operation == '-') {
		x = x - y;
		c = 0;
		Edit1->Text="Result = " + (FloatToStrF(x, ffGeneral, 5,2));
	}
	else if (operation == '*') {
		x = x * y;
		c = 0;
		Edit1->Text="Result = " + (FloatToStrF(x, ffGeneral, 5,2));
	}
	else if (operation == '/') {
		if (y == StrToFloat("0") ){
        Edit1->Text="Error";
		ShowMessage("Div by zero.");
		}
		x = x / y;
		c = 0;
		Edit1->Text="Result = " + (FloatToStrF(x, ffGeneral, 5,2));
	}
}

// ---------------------------------------------------------------------------
void __fastcall TForm4::Button10Click(TObject *Sender) {
	if (!c) {
		Edit1->Text = "0,";
		c = 1;
	}
	else if (Edit1->Text.Pos(",") == 0)
		Edit1->Text = Edit1->Text + ",";
}
// ---------------------------------------------------------------------------

void __fastcall TForm4::Button13Click(TObject *Sender)
{
int EditLen = Edit1->Text.Length();
if (EditLen == 0){
		ShowMessage("Edit is empty.");
		Edit1->Text="";
	}
	else{
		Edit1->Text=Edit1->Text.Delete(Edit1->Text.Length(),1);
	}
}
//---------------------------------------------------------------------------

