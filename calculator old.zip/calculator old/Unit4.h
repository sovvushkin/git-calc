// ---------------------------------------------------------------------------

#ifndef Unit4H
#define Unit4H
// ---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>

// ---------------------------------------------------------------------------
class TForm4 : public TForm {
__published: // IDE-managed Components
	TButton *Button1;
	TButton *Button2;
	TButton *Button3;
	TButton *Button4;
	TButton *Button5;
	TButton *Button6;
	TButton *Button7;
	TButton *Button8;
	TButton *Button9;
	TButton *Button10;
	TButton *Button11;
	TButton *Button12;
	TButton *Button13;
	TButton *Button14;
	TButton *Button15;
	TButton *Button16;
	TButton *Button17;
	TEdit *Edit1;
	TButton *Button18;

	void __fastcall Button1Click(TObject *Sender);
	void __fastcall Button12Click(TObject *Sender);
	void __fastcall Button14Click(TObject *Sender);
	void __fastcall Button11Click(TObject *Sender);
	void __fastcall Button10Click(TObject *Sender);
	void __fastcall Button13Click(TObject *Sender);

private: // User declarations
public: // User declarations
	__fastcall TForm4(TComponent* Owner);
};

// ---------------------------------------------------------------------------
extern PACKAGE TForm4 *Form4;
// ---------------------------------------------------------------------------
#endif
